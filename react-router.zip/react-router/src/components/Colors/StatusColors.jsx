import React from 'react'

const statusColors = {
    "yet_to_open": "bg-yellow-100 text-yellow-800",
    "in_progress": "bg-blue-100 text-blue-800",
    "resolved": "bg-green-100 text-green-800"
  };

export default statusColors