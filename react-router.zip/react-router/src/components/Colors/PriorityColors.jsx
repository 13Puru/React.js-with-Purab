import React from 'react'

const priorityColors = {
    "high": "bg-red-100 text-red-800",
    "medium": "bg-orange-100 text-orange-800",
    "low": "bg-gray-100 text-gray-800"
  };

export default priorityColors